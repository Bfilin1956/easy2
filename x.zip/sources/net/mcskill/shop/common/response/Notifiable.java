package net.mcskill.shop.common.response;

import gg.essential.elementa.UIComponent;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: Notifiable.kt */
/* JADX INFO: loaded from: MSShop-1.21.1-2.1.4-neoforge-client.jar:net/mcskill/shop/common/response/Notifiable.class */
@Metadata(mv = {2, 0, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001R\u0012\u0010\u0002\u001a\u00020\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0006À\u0006\u0001"}, d2 = {"Lnet/mcskill/shop/common/response/Notifiable;", "", "notificationSection", "Lgg/essential/elementa/UIComponent;", "getNotificationSection", "()Lgg/essential/elementa/UIComponent;", "MSShop"})
public interface Notifiable {
    @NotNull
    /* JADX INFO: renamed from: getNotificationSection */
    UIComponent mo10getNotificationSection();
}
